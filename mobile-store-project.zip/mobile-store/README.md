# Mobile Store

A responsive React + Vite project for a mobile phone store. Built to run in Visual Studio Code.

## Features
- Signup, login and logout
- Add, view, edit and delete mobile phones (CRUD)
- Search by mobile name, brand or category
- Filter by brand and sort by price/name
- Wishlist toggle and wishlist page
- Browser localStorage persistence
- Responsive layout for mobile and desktop

## Requirements
- Node.js 18 or newer
- Visual Studio Code

## Run in VS Code
1. Extract the ZIP file.
2. Open VS Code → **File → Open Folder** → select `mobile-store`.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm install
   npm run dev
   ```

5. Open the local URL shown in the terminal (usually `http://localhost:5173`).

## Demo use
- Select **Sign up**, create an account, then log in.
- Add/edit/delete mobiles using the store controls.
- Use the heart icon to add or remove wishlist items.

## Important note
This is a front-end academic/demo project. Authentication and data are stored in browser localStorage. It is not production-secure and does not use a backend database. Data is specific to the browser where it is used.

## Push to GitHub
Create a new empty repository on GitHub named `mobile-store`. Do not add a README or .gitignore there because this project already includes them.

In the VS Code terminal, from the project folder, run:

```bash
git init
git add .
git commit -m "Initial commit - Mobile Store project"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/mobile-store.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username. If Git asks you to sign in, complete the GitHub authentication prompt.

## Build check
```bash
npm run build
```
