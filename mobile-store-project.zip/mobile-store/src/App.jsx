import React, { useEffect, useMemo, useState } from 'react';
import { Search, Heart, Smartphone, Plus, LogOut, Pencil, Trash2, X, SlidersHorizontal, ShoppingBag } from 'lucide-react';

const starter = [
  {id:1,name:'iPhone 15',brand:'Apple',price:69999,category:'Premium',rating:4.8,image:'https://images.unsplash.com/photo-1695048133142-1a20484d2569?w=700',description:'Dynamic Island, advanced camera system and all-day battery.'},
  {id:2,name:'Samsung Galaxy S24',brand:'Samsung',price:74999,category:'Premium',rating:4.7,image:'https://images.unsplash.com/photo-1610945265064-0e34e5519bbf?w=700',description:'A powerful Android phone with a bright display and pro-grade camera.'},
  {id:3,name:'OnePlus 12R',brand:'OnePlus',price:39999,category:'Mid-range',rating:4.6,image:'https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=700',description:'Fast performance, smooth display and long-lasting battery.'},
  {id:4,name:'Redmi Note 13',brand:'Xiaomi',price:17999,category:'Budget',rating:4.4,image:'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=700',description:'Great everyday features at an affordable price.'},
  {id:5,name:'Google Pixel 8a',brand:'Google',price:42999,category:'Mid-range',rating:4.5,image:'https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=700',description:'Clean Android experience and smart computational photography.'},
  {id:6,name:'Nothing Phone (2a)',brand:'Nothing',price:23999,category:'Budget',rating:4.3,image:'https://images.unsplash.com/photo-1605236453806-6ff36851218e?w=700',description:'Distinctive design with a clean, simple user experience.'}
];
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const money = n => '₹' + Number(n).toLocaleString('en-IN');

export default function App() {
  const [user,setUser] = useState(() => read('ms_user', null));
  const [users,setUsers] = useState(() => read('ms_users', []));
  const [mobiles,setMobiles] = useState(() => read('ms_mobiles', starter));
  const [wish,setWish] = useState(() => read('ms_wish', []));
  const [page,setPage] = useState('store');
  const [query,setQuery] = useState('');
  const [brand,setBrand] = useState('All');
  const [sort,setSort] = useState('featured');
  const [modal,setModal] = useState(false);
  const [editing,setEditing] = useState(null);
  const [authMode,setAuthMode] = useState('login');
  const [notice,setNotice] = useState('');
  const [auth,setAuth] = useState({name:'',email:'',password:''});
  const [form,setForm] = useState({name:'',brand:'Apple',price:'',category:'Mid-range',rating:'4.5',image:'',description:''});

  useEffect(()=>localStorage.setItem('ms_user',JSON.stringify(user)),[user]);
  useEffect(()=>localStorage.setItem('ms_users',JSON.stringify(users)),[users]);
  useEffect(()=>localStorage.setItem('ms_mobiles',JSON.stringify(mobiles)),[mobiles]);
  useEffect(()=>localStorage.setItem('ms_wish',JSON.stringify(wish)),[wish]);

  const visible = useMemo(()=>{
    let data = mobiles.filter(m => (page !== 'wishlist' || wish.includes(m.id)) &&
      [m.name,m.brand,m.category].join(' ').toLowerCase().includes(query.toLowerCase()) &&
      (brand==='All' || m.brand===brand));
    if(sort==='low') data.sort((a,b)=>a.price-b.price);
    if(sort==='high') data.sort((a,b)=>b.price-a.price);
    if(sort==='name') data.sort((a,b)=>a.name.localeCompare(b.name));
    return data;
  },[mobiles,wish,page,query,brand,sort]);

  function submitAuth(e){
    e.preventDefault();
    const email=auth.email.trim().toLowerCase();
    if(authMode==='signup'){
      if(users.some(u=>u.email===email)){setNotice('An account with this email already exists.');return;}
      if(auth.password.length<6){setNotice('Password must contain at least 6 characters.');return;}
      const next=[...users,{name:auth.name,email,password:auth.password}]; setUsers(next); setUser({name:auth.name,email}); setNotice('');
    } else {
      const found=users.find(u=>u.email===email && u.password===auth.password);
      if(!found){setNotice('Invalid email or password. Please sign up first.');return;}
      setUser({name:found.name,email:found.email}); setNotice('');
    }
  }
  function logout(){setUser(null);setPage('store');setQuery('');}
  function toggleWish(id){setWish(old=>old.includes(id)?old.filter(x=>x!==id):[...old,id]);}
  function openAdd(){setEditing(null);setForm({name:'',brand:'Apple',price:'',category:'Mid-range',rating:'4.5',image:'',description:''});setModal(true);}
  function openEdit(m){setEditing(m.id);setForm({...m,price:String(m.price),rating:String(m.rating)});setModal(true);}
  function saveMobile(e){
    e.preventDefault();
    const item={...form,id:editing??Date.now(),price:Number(form.price),rating:Number(form.rating),image:form.image||'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=700'};
    if(!item.name.trim() || !item.price || item.price<1){return;}
    setMobiles(old=>editing?old.map(m=>m.id===editing?item:m):[item,...old]);setModal(false);
  }
  function removeMobile(id){if(confirm('Delete this mobile from the store?')){setMobiles(old=>old.filter(m=>m.id!==id));setWish(old=>old.filter(x=>x!==id));}}
  if(!user) return <main className="auth-page"><section className="auth-card"><div className="brand-mark"><Smartphone size={25}/></div><p className="eyebrow">YOUR NEXT UPGRADE</p><h1>Mobile Store</h1><p className="muted">Sign in to explore and manage your favourite phones.</p>
    <div className="tabs"><button className={authMode==='login'?'active':''} onClick={()=>{setAuthMode('login');setNotice('')}}>Login</button><button className={authMode==='signup'?'active':''} onClick={()=>{setAuthMode('signup');setNotice('')}}>Sign up</button></div>
    <form onSubmit={submitAuth} className="auth-form">{authMode==='signup'&&<label>Full name<input required value={auth.name} onChange={e=>setAuth({...auth,name:e.target.value})} placeholder="Your name"/></label>}<label>Email address<input required type="email" value={auth.email} onChange={e=>setAuth({...auth,email:e.target.value})} placeholder="you@example.com"/></label><label>Password<input required type="password" value={auth.password} onChange={e=>setAuth({...auth,password:e.target.value})} placeholder="At least 6 characters"/></label>{notice&&<p className="error">{notice}</p>}<button className="primary full">{authMode==='login'?'Login':'Create account'}</button></form>
    <p className="tiny">Demo project: accounts are stored in this browser using localStorage.</p></section></main>;

  return <div className="app-shell"><header className="topbar"><div className="logo"><span className="logo-icon"><Smartphone size={20}/></span><b>Mobile<span>Store</span></b></div><nav><button className={page==='store'?'selected':''} onClick={()=>setPage('store')}>All mobiles</button><button className={page==='wishlist'?'selected':''} onClick={()=>setPage('wishlist')}><Heart size={16}/> Wishlist <span className="count">{wish.length}</span></button></nav><div className="user-area"><span>Hi, {user.name.split(' ')[0]}</span><button className="logout" onClick={logout}><LogOut size={16}/> Logout</button></div></header>
  <main className="main"><section className="hero"><div><p className="eyebrow">SMARTER SHOPPING STARTS HERE</p><h1>Find the phone<br/>that fits <em>your life.</em></h1><p>Explore popular smartphones, compare prices and save your favourites.</p></div><div className="hero-art"><Smartphone size={115} strokeWidth={1}/><span className="spark">✦</span></div></section>
  <div className="section-head"><div><p className="eyebrow">THE COLLECTION</p><h2>{page==='wishlist'?'Your wishlist':'Explore mobiles'}</h2><p className="muted">{visible.length} phone{visible.length===1?'':'s'} found</p></div><button className="primary add-btn" onClick={openAdd}><Plus size={17}/> Add mobile</button></div>
  <section className="toolbar"><div className="search"><Search size={18}/><input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search by mobile or brand..."/>{query&&<button onClick={()=>setQuery('')}><X size={15}/></button>}</div><div className="filter"><SlidersHorizontal size={17}/><select value={brand} onChange={e=>setBrand(e.target.value)}><option>All</option>{[...new Set(mobiles.map(m=>m.brand))].sort().map(b=><option key={b}>{b}</option>)}</select></div><select className="sort" value={sort} onChange={e=>setSort(e.target.value)}><option value="featured">Sort: Featured</option><option value="low">Price: Low to high</option><option value="high">Price: High to low</option><option value="name">Name: A to Z</option></select></section>
  {visible.length===0?<div className="empty"><ShoppingBag size={36}/><h3>{page==='wishlist'?'Your wishlist is empty':'No mobiles found'}</h3><p className="muted">Try changing your search or filters.</p><button className="secondary" onClick={()=>{setQuery('');setBrand('All');setPage('store')}}>View all mobiles</button></div>:<section className="products">{visible.map(m=><article className="product-card" key={m.id}><div className="product-image"><img src={m.image} alt={m.name} onError={e=>e.currentTarget.src='https://placehold.co/600x400?text=Mobile'}/><button aria-label="Toggle wishlist" className={'heart '+(wish.includes(m.id)?'hearted':'')} onClick={()=>toggleWish(m.id)}><Heart size={18} fill={wish.includes(m.id)?'currentColor':'none'}/></button><span className="category">{m.category}</span></div><div className="product-info"><div className="product-meta"><span>{m.brand}</span><span>★ {m.rating}</span></div><h3>{m.name}</h3><p>{m.description}</p><div className="product-bottom"><strong>{money(m.price)}</strong><div><button className="icon-btn" title="Edit mobile" onClick={()=>openEdit(m)}><Pencil size={16}/></button><button className="icon-btn danger" title="Delete mobile" onClick={()=>removeMobile(m.id)}><Trash2 size={16}/></button></div></div></div></article>)}</section>}
  <footer>© 2026 Mobile Store · Built with React and Vite</footer></main>
  {modal&&<div className="overlay" onClick={e=>e.target===e.currentTarget&&setModal(false)}><section className="modal"><div className="modal-head"><div><p className="eyebrow">STORE INVENTORY</p><h2>{editing?'Edit mobile':'Add a mobile'}</h2></div><button className="icon-btn" onClick={()=>setModal(false)}><X/></button></div><form onSubmit={saveMobile} className="mobile-form"><label>Mobile name<input required value={form.name} onChange={e=>setForm({...form,name:e.target.value})} placeholder="e.g. iPhone 15"/></label><div className="form-row"><label>Brand<select value={form.brand} onChange={e=>setForm({...form,brand:e.target.value})}>{['Apple','Samsung','OnePlus','Xiaomi','Google','Nothing','Other'].map(x=><option>{x}</option>)}</select></label><label>Price (₹)<input required type="number" min="1" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} placeholder="49999"/></label></div><div className="form-row"><label>Category<select value={form.category} onChange={e=>setForm({...form,category:e.target.value})}>{['Budget','Mid-range','Premium'].map(x=><option>{x}</option>)}</select></label><label>Rating<input type="number" min="0" max="5" step=".1" value={form.rating} onChange={e=>setForm({...form,rating:e.target.value})}/></label></div><label>Image URL<input value={form.image} onChange={e=>setForm({...form,image:e.target.value})} placeholder="https://..."/></label><label>Description<textarea rows="3" value={form.description} onChange={e=>setForm({...form,description:e.target.value})} placeholder="Short description"/></label><button className="primary full">{editing?'Save changes':'Add mobile'}</button></form></section></div>}</div>;
}